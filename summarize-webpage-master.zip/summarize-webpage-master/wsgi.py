from app import app as application

if __name__ == "__main__":
    # run the app
    application.run()
